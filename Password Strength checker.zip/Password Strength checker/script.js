function checkPasswordStrength() {
    var password = document.getElementById('password').value;
    var strengthMessage = document.getElementById('strengthMessage');

    var strength = 0;

    if (password.length >= 8) strength++;
    if (/[a-z]/.test(password)) strength++;
    if (/[A-Z]/.test(password)) strength++;
    if (/[0-9]/.test(password)) strength++;
    if (/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) strength++;

    var strengthLevel = "";
    switch (strength) {
        case 5:
            strengthLevel = "Very Strong";
            strengthMessage.style.color = "green";
            break;
        case 4:
            strengthLevel = "Strong";
            strengthMessage.style.color = "blue";
            break;
        case 3:
            strengthLevel = "Moderate";
            strengthMessage.style.color = "orange";
            break;
        case 2:
            strengthLevel = "Weak";
            strengthMessage.style.color = "red";
            break;
        case 1:
        case 0:
            strengthLevel = "Very Weak";
            strengthMessage.style.color = "darkred";
            break;
    }

    strengthMessage.textContent = "Password Strength: " + strengthLevel;
}
